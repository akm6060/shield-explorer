# Shield Explorer — Android starter build

This is an early native Kotlin Android prototype for an encrypted file manager.

## Current prototype functionality
- Create a password-protected vault stored in the app's private directory.
- Encrypt the vault payload on disk using AES-256-GCM.
- Derive encryption keys with PBKDF2-HMAC-SHA-256 (310,000 iterations).
- Import selected files into the vault and immediately browse their names after unlock.
- Preview text and images inside the app.
- Export an explicitly selected plaintext copy.
- Encrypt an individual file to a `.sfe` file and open it inside the app with its password.
- Lock the vault and clear application-held buffers on a best-effort basis.
- GitHub Actions workflow builds a debug APK and uploads it as an artifact.

## Important limitations
This is a starter prototype, not a production replacement for Solid Explorer.
It does not yet include dual-pane browsing, full folder-tree import, archive handling, network storage, video/audio playback, full document previews, biometric unlock, secure deletion, or a hardened audit of memory and temporary data. Individual encrypted files currently use a password derived from the currently unlocked vault password.
The vault serializes its contents into memory during save/open; very large files may exhaust memory. Do not use it as the only copy of important data. The prototype does not delete source files after encryption, deliberately avoiding accidental data loss. Verify encrypted output and delete plaintext originals yourself if desired.
A correct password and compatible implementation can decrypt the format; no file encryption can guarantee that only one specific application can ever read data.
Before real-world sensitive use, this code needs security review, streaming encryption, memory hardening, encrypted thumbnail/cache policy, and extensive testing.
## Build
Run `gradle assembleDebug` with Java 17 and Android SDK support, or push to GitHub and run the **Build Android APK** workflow. The resulting debug APK is `app/build/outputs/apk/debug/app-debug.apk`.
