package com.example.shieldexplorer

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import java.io.*
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Initial native prototype. Vault payloads remain encrypted on disk.
 * Plaintext is only materialized in memory for browsing/preview.
 */
class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var list: LinearLayout
    private val vaultFile by lazy { File(filesDir, "private-vault.svx") }
    private val entries = mutableListOf<VaultEntry>()
    private var unlocked = false
    private var currentPassword: CharArray? = null

    data class VaultEntry(val name: String, val mime: String, val bytes: ByteArray)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        refresh()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 22, 20, 16)
            setBackgroundColor(0xFFF4F6FA.toInt())
        }
        val title = TextView(this).apply {
            text = "Shield Explorer"
            textSize = 26f
            setTextColor(0xFF14213D.toInt())
            gravity = Gravity.CENTER_VERTICAL
        }
        root.addView(title, LinearLayout.LayoutParams(-1, 56))
        val subtitle = TextView(this).apply {
            text = "Encrypted storage • Private vault"
            textSize = 14f
            setTextColor(0xFF526079.toInt())
        }
        root.addView(subtitle)
        status = TextView(this).apply {
            textSize = 14f
            setPadding(0, 14, 0, 12)
        }
        root.addView(status)
        addButton("Create / unlock vault") { promptPassword() }
        addButton("Import files into vault") {
            if (!unlocked) toast("Unlock or create the vault first.")
            else pickFiles()
        }
        addButton("Lock vault") { lockVault() }
        addButton("Encrypt one file to .sfe") { pickFileForStandaloneEncryption() }
        addButton("Open .sfe file in this app") { pickEncryptedFile() }
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun addButton(label: String, action: () -> Unit) {
        val button = Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
        }
        root.addView(button, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    private fun refresh() {
        status.text = when {
            unlocked -> "Vault unlocked. ${entries.size} item(s). Files on disk remain encrypted."
            vaultFile.exists() -> "Vault exists and is locked."
            else -> "No vault yet. Create one with a password."
        }
        list.removeAllViews()
        if (unlocked) entries.forEach { entry ->
            val b = Button(this).apply {
                text = "📄  ${entry.name}"
                isAllCaps = false
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
                setOnClickListener { preview(entry) }
                setOnLongClickListener {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle(entry.name)
                        .setMessage("Remove this item from the vault?")
                        .setNegativeButton("Cancel", null)
                        .setPositiveButton("Remove") { _, _ ->
                            entries.remove(entry); saveVault(); refresh()
                        }.show()
                    true
                }
            }
            list.addView(b)
        }
    }

    private fun promptPassword() {
        val box = EditText(this).apply {
            hint = "Vault password"
            inputType = 129
        }
        AlertDialog.Builder(this)
            .setTitle(if (vaultFile.exists()) "Unlock vault" else "Create encrypted vault")
            .setMessage("Use a strong password. If it is lost, the encrypted data cannot be recovered.")
            .setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Continue") { _, _ ->
                val password = box.text.toString()
                if (password.length < 10) {
                    toast("Use at least 10 characters.")
                } else if (vaultFile.exists()) {
                    try {
                        entries.clear()
                        entries.addAll(readVault(password.toCharArray()))
                        currentPassword = password.toCharArray()
                        unlocked = true
                        refresh()
                    } catch (_: Exception) {
                        toast("Could not unlock. The password may be wrong or the vault may be damaged.")
                    }
                } else {
                    entries.clear()
                    currentPassword = password.toCharArray()
                    unlocked = true
                    saveVault()
                    refresh()
                }
            }.show()
    }

    private fun pickFiles() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(i, REQ_IMPORT)
    }

    @Deprecated("Use activity result APIs in production release")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        when (requestCode) {
            REQ_IMPORT -> {
                val uris = mutableListOf<Uri>()
                data.clipData?.let { clip ->
                    for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri)
                } ?: data.data?.let { uris.add(it) }
                try {
                    for (uri in uris) {
                        val name = displayName(uri) ?: "file-${System.currentTimeMillis()}"
                        val mime = contentResolver.getType(uri) ?: "application/octet-stream"
                        val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                            ?: throw IOException("Unable to read selected file")
                        entries.add(VaultEntry(name, mime, bytes))
                    }
                    saveVault()
                    refresh()
                    toast("Imported ${uris.size} file(s). The vault remains encrypted on disk.")
                } catch (e: Exception) {
                    toast("Import failed: ${e.message ?: "unknown error"}")
                }
            }
            REQ_ENCRYPT_FILE -> {
                val uri = data.data ?: return
                val password = currentPassword
                if (password == null) { toast("Unlock the vault first."); return }
                try {
                    val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return
                    val name = displayName(uri) ?: "encrypted-file"
                    val mime = contentResolver.getType(uri) ?: "application/octet-stream"
                    val output = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        type = "application/octet-stream"
                        putExtra(Intent.EXTRA_TITLE, "$name.sfe")
                        addCategory(Intent.CATEGORY_OPENABLE)
                    }
                    pendingStandalone = Standalone(name, mime, bytes, password.copyOf())
                    startActivityForResult(output, REQ_SAVE_ENCRYPTED)
                } catch (e: Exception) { toast("Could not read source: ${e.message}") }
            }
            REQ_SAVE_ENCRYPTED -> {
                val uri = data.data ?: return
                val pending = pendingStandalone ?: return
                try {
                    val packed = packEntry(pending.name, pending.mime, pending.bytes)
                    val encrypted = encrypt(packed, pending.password)
                    contentResolver.openOutputStream(uri)?.use { it.write(MAGIC); it.write(encrypted) }
                    pending.password.fill('\u0000')
                    pendingStandalone = null
                    toast("Encrypted file saved. Delete the original yourself only after verifying the saved copy.")
                } catch (e: Exception) { toast("Encryption failed: ${e.message}") }
            }
            REQ_OPEN_ENCRYPTED -> {
                val uri = data.data ?: return
                val box = EditText(this).apply { hint = "Password"; inputType = 129 }
                AlertDialog.Builder(this).setTitle("Unlock encrypted file").setView(box)
                    .setNegativeButton("Cancel", null).setPositiveButton("Open") { _, _ ->
                        try {
                            val raw = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return@setPositiveButton
                            if (!raw.copyOfRange(0, MAGIC.size).contentEquals(MAGIC)) throw IOException("Not a supported .sfe file")
                            val decoded = unpackEntry(decrypt(raw.copyOfRange(MAGIC.size, raw.size), box.text.toString().toCharArray()))
                            preview(decoded)
                        } catch (_: Exception) { toast("Incorrect password or invalid encrypted file.") }
                    }.show()
            }
            REQ_SAVE_EXPORT -> {
                val uri = data.data ?: return
                val payload = pendingExport ?: return
                contentResolver.openOutputStream(uri)?.use { it.write(payload) }
                pendingExport = null
                toast("Exported plaintext copy. Protect it appropriately.")
            }
        }
    }

    private data class Standalone(val name: String, val mime: String, val bytes: ByteArray, val password: CharArray)
    private var pendingStandalone: Standalone? = null
    private var pendingExport: ByteArray? = null

    private fun pickFileForStandaloneEncryption() {
        if (currentPassword == null) { toast("Unlock or create a vault first; its password will protect this file."); return }
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE) }
        startActivityForResult(i, REQ_ENCRYPT_FILE)
    }

    private fun pickEncryptedFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(i, REQ_OPEN_ENCRYPTED)
    }

    private fun preview(entry: VaultEntry) {
        if (entry.mime.startsWith("text/") || entry.name.endsWith(".txt", true) ||
            entry.name.endsWith(".json", true) || entry.name.endsWith(".xml", true)) {
            val text = entry.bytes.toString(Charsets.UTF_8).take(50000)
            AlertDialog.Builder(this).setTitle(entry.name).setMessage(text)
                .setPositiveButton("Close", null)
                .setNeutralButton("Export copy") { _, _ -> exportEntry(entry) }.show()
        } else if (entry.mime.startsWith("image/")) {
            val bitmap = BitmapFactory.decodeByteArray(entry.bytes, 0, entry.bytes.size)
            if (bitmap == null) { toast("Image could not be decoded."); return }
            val image = ImageView(this).apply { setImageBitmap(bitmap); adjustViewBounds = true }
            AlertDialog.Builder(this).setTitle(entry.name).setView(image)
                .setPositiveButton("Close", null)
                .setNeutralButton("Export copy") { _, _ -> exportEntry(entry) }.show()
        } else {
            AlertDialog.Builder(this).setTitle(entry.name)
                .setMessage("Preview for ${entry.mime} is not included in this starter build. Exporting creates a plaintext copy.")
                .setNegativeButton("Close", null)
                .setPositiveButton("Export copy") { _, _ -> exportEntry(entry) }.show()
        }
    }

    private fun exportEntry(entry: VaultEntry) {
        pendingExport = entry.bytes
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            type = entry.mime
            putExtra(Intent.EXTRA_TITLE, entry.name)
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(i, REQ_SAVE_EXPORT)
    }

    private fun saveVault() {
        val password = currentPassword ?: return
        try {
            val bytes = ByteArrayOutputStream().use { buffer ->
                DataOutputStream(buffer).use { out ->
                    out.writeInt(entries.size)
                    entries.forEach {
                        out.writeUTF(it.name); out.writeUTF(it.mime)
                        out.writeInt(it.bytes.size); out.write(it.bytes)
                    }
                }
                buffer.toByteArray()
            }
            val encrypted = encrypt(bytes, password)
            FileOutputStream(vaultFile).use { it.write(MAGIC); it.write(encrypted) }
            bytes.fill(0)
        } catch (e: Exception) { toast("Vault save failed: ${e.message}") }
    }

    private fun readVault(password: CharArray): List<VaultEntry> {
        val raw = vaultFile.readBytes()
        if (raw.size < MAGIC.size || !raw.copyOfRange(0, MAGIC.size).contentEquals(MAGIC))
            throw IOException("Invalid vault")
        val plain = decrypt(raw.copyOfRange(MAGIC.size, raw.size), password)
        return DataInputStream(ByteArrayInputStream(plain)).use { input ->
            val count = input.readInt()
            if (count < 0 || count > 100000) throw IOException("Invalid item count")
            val result = mutableListOf<VaultEntry>()
            repeat(count) {
                val name = input.readUTF()
                val mime = input.readUTF()
                val size = input.readInt()
                if (size < 0 || size > input.available()) throw IOException("Invalid entry")
                val bytes = ByteArray(size); input.readFully(bytes)
                result.add(VaultEntry(name, mime, bytes))
            }
            plain.fill(0)
            result
        }
    }

    private fun encrypt(plain: ByteArray, password: CharArray): ByteArray {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val nonce = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val spec = PBEKeySpec(password, salt, 310000, 256)
        val keyBytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        spec.clearPassword()
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(keyBytes, "AES"), GCMParameterSpec(128, nonce))
        val cipherText = cipher.doFinal(plain)
        keyBytes.fill(0)
        return ByteArrayOutputStream().use { b ->
            DataOutputStream(b).use { out -> out.writeByte(1); out.write(salt); out.write(nonce); out.writeInt(cipherText.size); out.write(cipherText) }
            b.toByteArray()
        }
    }

    private fun decrypt(data: ByteArray, password: CharArray): ByteArray {
        val input = DataInputStream(ByteArrayInputStream(data))
        val version = input.readUnsignedByte()
        if (version != 1) throw IOException("Unsupported format")
        val salt = ByteArray(16); input.readFully(salt)
        val nonce = ByteArray(12); input.readFully(nonce)
        val size = input.readInt()
        if (size < 16 || size > input.available()) throw IOException("Invalid encrypted payload")
        val cipherText = ByteArray(size); input.readFully(cipherText)
        val spec = PBEKeySpec(password, salt, 310000, 256)
        val keyBytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        spec.clearPassword()
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(keyBytes, "AES"), GCMParameterSpec(128, nonce))
        return try { cipher.doFinal(cipherText) } finally { keyBytes.fill(0); password.fill('\u0000') }
    }

    private fun packEntry(name: String, mime: String, bytes: ByteArray): ByteArray =
        ByteArrayOutputStream().use { b ->
            DataOutputStream(b).use { out -> out.writeUTF(name); out.writeUTF(mime); out.writeInt(bytes.size); out.write(bytes) }
            b.toByteArray()
        }

    private fun unpackEntry(data: ByteArray): VaultEntry =
        DataInputStream(ByteArrayInputStream(data)).use { input ->
            val name = input.readUTF(); val mime = input.readUTF(); val size = input.readInt()
            if (size < 0 || size > input.available()) throw IOException("Invalid payload")
            val bytes = ByteArray(size); input.readFully(bytes); data.fill(0)
            VaultEntry(name, mime, bytes)
        }

    private fun displayName(uri: Uri): String? {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { if (it.moveToFirst()) return it.getString(0) }
        return uri.lastPathSegment
    }

    private fun lockVault() {
        entries.forEach { it.bytes.fill(0) }
        entries.clear()
        currentPassword?.fill('\u0000')
        currentPassword = null
        unlocked = false
        refresh()
        toast("Vault locked.")
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    companion object {
        private const val REQ_IMPORT = 10
        private const val REQ_ENCRYPT_FILE = 11
        private const val REQ_SAVE_ENCRYPTED = 12
        private const val REQ_OPEN_ENCRYPTED = 13
        private const val REQ_SAVE_EXPORT = 14
        private val MAGIC = byteArrayOf(0x53, 0x56, 0x58, 0x31) // SVX1
    }
}
